# Iron Vale: Android APK build kit

This wraps the game in a Capacitor Android app (landscape-locked, fullscreen).
It has NOT been built or tested: the environment that produced it had no Android SDK and no network.

## Requirements
Node 18+, JDK 17, Android Studio (or the Android SDK command-line tools with ANDROID_HOME set).

## Steps
```
npm install
npm run vendor      # optional: bundle three.js so the game works offline
npm run android     # adds the Android project, forces landscape + fullscreen, syncs www/
npm run apk         # builds android/app/build/outputs/apk/debug/app-debug.apk
```
Install: `adb install android/app/build/outputs/apk/debug/app-debug.apk`
(or open the `android` folder in Android Studio and press Run).

Without `npm run vendor` the game loads three.js from cdnjs and needs internet.
For a Play Store release you must sign a release build (Build > Generate Signed Bundle / APK).

## No Android Studio? Build it on GitHub (free)
1. Create a new GitHub repo and upload everything in this folder (including the hidden `.github` folder).
2. Open the repo's Actions tab. "Build APK" runs on every push (or press "Run workflow").
3. When it turns green, open the run and download the `iron-vale-apk` artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, allow "install unknown apps" for your file manager, and tap it.
